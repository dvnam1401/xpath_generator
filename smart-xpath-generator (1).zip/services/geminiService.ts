// This service has been disabled as AI features were removed from the project.
export const createChatSession = () => {
  throw new Error("AI features are disabled.");
};