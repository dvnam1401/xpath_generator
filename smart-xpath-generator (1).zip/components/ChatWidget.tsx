import React from 'react';

// ChatWidget is disabled.
export const ChatWidget: React.FC = () => {
  return null;
};